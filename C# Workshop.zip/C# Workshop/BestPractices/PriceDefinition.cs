public class PriceDefinition
{
    public double pricePerUnit;
    public double basePrice;

}