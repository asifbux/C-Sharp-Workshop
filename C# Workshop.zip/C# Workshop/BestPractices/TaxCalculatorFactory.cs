using System.Collections.Generic;
public class TaxCalculatorFactory {
    public Dictionary<string, ITaxCalculator> _calculator;
    public TaxCalculatorFactory() {
        _calculator = new Dictionary<string, ITaxCalculator>
        {
            {"AB", new AlbertaTaxCalculator()},
            {"ON", new OntarioTaxCalculator()},
        };
    }
    public ITaxCalculator getTaxCalculator(string province) {
        return _calculator[province];
    }
}