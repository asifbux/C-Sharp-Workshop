﻿
// This class contains a few examples of bad practices in writing software. 
// There are some "Code Smells" here pointing to problems.
// Check these out:
// https://refactoring.guru/smells/long-parameter-list
// https://sourcemaking.com/refactoring/smells/long-method
// https://sourcemaking.com/refactoring/smells/primitive-obsession
// https://sourcemaking.com/refactoring/smells/switch-statements

namespace BestPractices
{
    // How to make sure the functionality of this class is not broken after making changes? Unit testing
    // https://docs.microsoft.com/en-us/dotnet/core/testing/unit-testing-with-dotnet-test
    public class Pizza
    {

        // How many arguments is too many?
        // Is this function doing too much? (Think single responsibility)
        // Do we have to pass all these arguments every time?
        // Can naming of the arguments be more clear?
        ITaxCalculator _taxCalculator;
        int numberOfToppings;
        PriceDefinition priceDefinition;
        public Pizza(ITaxCalculator taxCalculator, int num, PriceDefinition myprice) {
            _taxCalculator = taxCalculator;
            numberOfToppings = num;
            priceDefinition = myprice;
        }
        public double CalculatePrice()
        {

            double price = priceDefinition.basePrice;

            price = priceDefinition.pricePerUnit * numberOfToppings + price;

            // primitative obession 
            // Is there repeated code? (Follow Don't Repeat Yourself or DRY principle)
            // Is this code closed to modifications and open to new province and tax rules extensions? (Open closed principle)
            // Is there a way to break down this piece of code into even smaller pieces of functionality (provincial and federal tax)?
            price = _taxCalculator.getTotalAfterTax(price);

            return price;
        }
    }
}
