public interface ITaxCalculator
{
    double getTotalAfterTax(double price);
}