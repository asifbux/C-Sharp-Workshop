public class OntarioTaxCalculator: ITaxCalculator
{
    public double getTotalAfterTax(double price)
    {
        return price + price * 0.13;
    }
}