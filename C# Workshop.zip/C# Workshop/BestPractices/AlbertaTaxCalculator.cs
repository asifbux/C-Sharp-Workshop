public class AlbertaTaxCalculator: ITaxCalculator
{
    public double getTotalAfterTax(double price)
    {
        return price + price * 0.05;
    }
}