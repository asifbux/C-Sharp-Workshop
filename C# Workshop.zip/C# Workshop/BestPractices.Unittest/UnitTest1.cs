using System;
using Xunit;
using BestPractices;

namespace BestPractices.Unittest
{
    public class UnitTest1
    {
        [Fact]
        public void calculateAlbertaTax()
        {
        PriceDefinition priceDefinition = new PriceDefinition
            {
                basePrice = 9,
                pricePerUnit = 1 

            };
            Pizza p = new Pizza(new AlbertaTaxCalculator(), 1 ,priceDefinition);
            double expected = 10.5;
            double total = p.CalculatePrice();
            Assert.Equal(expected,total);

        }
        [Fact]
        public void CreateAlberaTaxCalculator() 
        {
            //Arrange
            var taxCalculatorFactory = new TaxCalculatorFactory();

            //Act
            ITaxCalculator result = taxCalculatorFactory.getTaxCalculator("AB");

            //Assert
            Assert.IsType<AlbertaTaxCalculator>(result);
        }
    }
}
